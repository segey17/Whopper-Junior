<template>
    <v-container>
      <v-row>
        <v-col>
          <h1>Board View</h1>
          <!-- Здесь будет отображаться доска с задачами -->
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script>
  export default {};
  </script>