<template>
    <v-container>
      <v-row>
        <v-col>
          <h1>Welcome to Task Manager</h1>
          <p>Manage your tasks efficiently with our platform.</p>
        </v-col>
      </v-row>
    </v-container>
  </template>
  
  <script>
  export default {};
  </script>